<!--footer start-->
<footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>KodPlex</strong>. All Rights Reserved
        </p>
      </div>
</footer>
<!--footer end-->